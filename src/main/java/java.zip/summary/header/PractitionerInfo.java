package summary.header;

import org.hl7.fhir.r4.model.Practitioner;
import summary.Terminology;
import summary.baseResource;

//진료의 정보
public class PractitionerInfo extends baseResource {
    static int resourceNum = 0;
    Practitioner practitioner = new Practitioner();

    //의료진성명, 의료진면허번호, 의료진 연락처, 진료과명, 진료과코드
    public PractitionerInfo(String name, String licenceNum, String tel,
                            String department, String departmentCode){

        this.setMetaData(practitioner, Terminology.PRACTITIONER_INFO, resourceNum);

        practitioner.addName().setText(name);
        practitioner.addIdentifier().setValue(licenceNum);
        practitioner.addTelecom().setValue(tel);
        practitioner.addQualification().getCode().addCoding()
                .setDisplay(department)
                .setCode(departmentCode);
    }

    public Practitioner getPractitioner(){
        return practitioner;
    }
}
