package summary;

import ca.uhn.fhir.context.FhirContext;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;

import java.text.SimpleDateFormat;
import java.util.Date;

public class baseResource {

    public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyymmdd");

    public void setMetaData(Resource resource, String ResourceName, int resourceNum){
        resource.setId(ResourceName + resourceNum++); //*추후 수정해야할듯
        resource.getMeta().setLastUpdated(new Date());
    }
}
