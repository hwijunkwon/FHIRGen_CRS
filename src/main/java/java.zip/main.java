
import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import org.hl7.fhir.r4.model.Enumerations;
import org.hl7.fhir.r4.model.Patient;
import summary.*;
import summary.header.*;

import java.util.Date;

public class main {
    public static void main(String[] args){
        FhirContext ctx = FhirContext.forR4();

        //임상문서명, 임상문서코드, 문서ID, 의뢰번호
        DocumentInfo documentInfo = new DocumentInfo("임상문서명", "임상문서코드", "문서id", "의뢰번호");

        PatientInfo patientInfo = new PatientInfo("환자id", "성명", "19910101", Enumerations.AdministrativeGender.MALE,
                "010-1111-1111", "주소", "진료구분코드", "진료구분코드명칭");
        PractitionerInfo practitionerInfo = new PractitionerInfo("진료의성명", "면허번호", "전화", "진료과명", "진료과코드");
        OrganizationInfo organizationInfo = new OrganizationInfo("기관식별번호", "기관기호", "기관명", "010-1234-1234", "주소");
        DocumentWriterInfo documentWriterInfo = new DocumentWriterInfo("문서작성자 id", "문서작성자 성명", "문서작성자 연락처");

        documentInfo.addResource(patientInfo.getPatient());
        documentInfo.addResource(practitionerInfo.getPractitioner());
        documentInfo.addResource(organizationInfo.getOrganization());
        documentInfo.addResource(documentWriterInfo.getPerson());

        AllergyInfo allergyInfo = new AllergyInfo("","","","","","");
        DiagnosisInfo diagnosisInfo = new DiagnosisInfo("", "","","");
        DrinkInfo drinkInfo = new DrinkInfo("", "");
        ImmunizationInfo immunizationInfo = new ImmunizationInfo("", "","", "", "");
        InfectionInfo infectionInfo = new InfectionInfo("", "", "", "", "", "", "", "", "");
        MedicationInfo medicationInfo = new MedicationInfo("", "", "", "", "", "", "", "", "", "");
        ProcedureInfo procedureInfo = new ProcedureInfo("", "", "", "", "", "");
        SmokeInfo smokeInfo = new SmokeInfo("", "");
        TestResultInfo testResultInfo = new TestResultInfo("", "", "", "", "", "", "");
        VitalsignInfo vitalsignInfo = new VitalsignInfo("", "", "", "", "", "");

        documentInfo.addResource(allergyInfo.getAllergyIntolerance());
        documentInfo.addResource(diagnosisInfo.getCondition());
        documentInfo.addResource(drinkInfo.getObservation());
        documentInfo.addResource(immunizationInfo.getImmunization());
        documentInfo.addResource(infectionInfo.getCondition());
        documentInfo.addResource(medicationInfo.getMedicationStatement());
        documentInfo.addResource(procedureInfo.getProcedure());
        documentInfo.addResource(smokeInfo.getObservation());
        documentInfo.addResource(testResultInfo.getObservation());
        documentInfo.addResource(vitalsignInfo.getObservation());

        System.out.println(ctx.newXmlParser().setPrettyPrint(true).encodeResourceToString(documentInfo.getBundle()));

    }
}
